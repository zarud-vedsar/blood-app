<?php
// Load and initialize PHPMailer library for sending emails
require_once("../phpmailer/vendor/autoload.php");

// Import necessary PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
?>